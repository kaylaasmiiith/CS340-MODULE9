
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure

class AnimalShelter:
    """
    CRUD operations for Animal database in MongoDB.
    """

    def __init__(self, username, password):
        try:
            self.client = MongoClient(f'mongodb://{username}:{password}@localhost:32963')
            self.database = self.client['AAC']  # Use the AAC database
            print("Connected to MongoDB successfully.")
        except ConnectionFailure as e:
            print(f"Could not connect to MongoDB: {e}")

    def create(self, data, collection_name):
        """Insert a document into the collection."""
        if data is not None:
            try:
                collection = self.database[collection_name]
                result = collection.insert_one(data)
                return True if result.acknowledged else False
            except Exception as e:
                print(f"Create operation failed: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, query, collection_name):
        """Read document(s) from the collection."""
        try:
            collection = self.database[collection_name]
            result = list(collection.find(query))
            return result
        except Exception as e:
            print(f"Read operation failed: {e}")
            return []

    def update(self, query, new_values, collection_name):
        """Update document(s) in the collection."""
        try:
            collection = self.database[collection_name]
            result = collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as e:
            print(f"Update operation failed: {e}")
            return 0

    def delete(self, query, collection_name):
        """Delete document(s) from the collection."""
        try:
            collection = self.database[collection_name]
            result = collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete operation failed: {e}")
            return 0
